# Elio 0.1

Primeira versão do assistente pessoal Elio.

## O que já funciona

- Interface simples do Elio.
- Permissão de microfone.
- Reconhecimento de voz em português do Brasil.
- Conversão da resposta para voz.
- Respostas básicas sem internet.
- GitHub Actions para gerar o APK automaticamente.

## Como compilar pelo GitHub

1. Crie um repositório no GitHub chamado `Elio`.
2. Envie todos os arquivos deste projeto.
3. Abra a aba **Actions**.
4. Execute **Build Elio APK**.
5. Quando terminar, abra a execução e baixe o artefato `Elio-0.1-debug`.
6. Dentro dele estará `app-debug.apk`.

## Próximas versões

Elio 0.2:
- interface melhor;
- histórico da conversa;
- mais comandos locais.

Elio 0.3:
- integração com um modelo de IA.

Elio 0.4+:
- ativação por palavra-chave;
- permissões avançadas;
- comandos de aplicativos;
- memória configurável.
