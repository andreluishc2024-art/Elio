package com.elio.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var status: TextView
    private lateinit var heard: TextView
    private lateinit var talkButton: Button
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var tts: TextToSpeech

    private val audioRequestCode = 100
    private var isListening = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        heard = findViewById(R.id.heard)
        talkButton = findViewById(R.id.talkButton)

        tts = TextToSpeech(this, this)

        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "O reconhecimento de voz não está disponível neste celular."
            talkButton.isEnabled = false
            return
        }

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(listener)

        talkButton.setOnClickListener {
            if (isListening) stopListening() else startListening()
        }

        status.text = "Fala. Tô ouvindo."
    }

    private fun startListening() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                audioRequestCode
            )
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        heard.text = ""
        status.text = "Tô ouvindo..."
        talkButton.text = "PARAR"
        isListening = true
        speechRecognizer.startListening(intent)
    }

    private fun stopListening() {
        speechRecognizer.stopListening()
        isListening = false
        talkButton.text = "FALAR COM ELIO"
        status.text = "Pronto."
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            status.text = "Pode falar..."
        }

        override fun onBeginningOfSpeech() {
            status.text = "Tô ouvindo..."
        }

        override fun onRmsChanged(rmsdB: Float) {}

        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            isListening = false
            talkButton.text = "FALAR COM ELIO"
            status.text = "Processando..."
        }

        override fun onError(error: Int) {
            isListening = false
            talkButton.text = "FALAR COM ELIO"
            status.text = "Não consegui entender. Tenta de novo."
        }

        override fun onResults(results: Bundle?) {
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull().orEmpty()

            if (text.isNotBlank()) {
                heard.text = "Você: $text"
                respond(text)
            } else {
                status.text = "Não ouvi nada."
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val matches = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull().orEmpty()
            if (text.isNotBlank()) heard.text = "Você: $text"
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun respond(input: String) {
        val normalized = input.lowercase(Locale("pt", "BR")).trim()

        val response = when {
            normalized.contains("oi") ||
            normalized.contains("olá") ||
            normalized.contains("ola") -> "Fala. Tô ouvindo."

            normalized.contains("seu nome") -> "Meu nome é Elio."

            normalized.contains("quem é você") ||
            normalized.contains("quem e voce") -> "Eu sou o Elio, seu assistente."

            normalized.contains("obrigado") ||
            normalized.contains("obrigada") -> "Tamo junto."

            else -> "Entendi. Ainda estou aprendendo a fazer isso."
        }

        status.text = response
        speak(response)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "elio-response")
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale("pt", "BR")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == audioRequestCode &&
            grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == audioRequestCode) {
            status.text = "Preciso do microfone para ouvir você."
        }
    }

    override fun onDestroy() {
        if (::speechRecognizer.isInitialized) speechRecognizer.destroy()
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
